window.PRODUCTS = [
  {
    id:'god-of-war', title:'God of War', short:'Эпическое приключение Кратоса в мире северных богов.',
    price:4990, platform:'PS4 / PS5', genre:'Action / Adventure', release:'2018', rating:'18+', page:'god-of-war.html',
    images:['assets/images/god-of-war-1.svg','assets/images/god-of-war-2.svg','assets/images/god-of-war-3.svg']
  },
  {
    id:'gta-5', title:'GTA V', short:'Большой открытый мир, сюжетная кампания и динамичный экшен.',
    price:2990, platform:'PS4 / PS5 / PC', genre:'Open World / Action', release:'2013', rating:'18+', page:'gta-5.html',
    images:['assets/images/gta-5-1.svg','assets/images/gta-5-2.svg','assets/images/gta-5-3.svg']
  },
  {
    id:'ufc-6', title:'UFC 6', short:'Демо-карточка спортивного файтинга с акцентом на октагон.',
    price:5990, platform:'PS5 / Xbox Series', genre:'Sports / Fighting', release:'Demo', rating:'16+', page:'ufc-6.html',
    images:['assets/images/ufc-6-1.svg','assets/images/ufc-6-2.svg','assets/images/ufc-6-3.svg']
  },
  {
    id:'fc-26', title:'EA Sports FC 26', short:'Футбольный магазинный демо-товар с быстрым переходом к покупке.',
    price:6490, platform:'PS5 / Xbox / PC', genre:'Sports / Football', release:'2025', rating:'3+', page:'fc-26.html',
    images:['assets/images/fc-26-1.svg','assets/images/fc-26-2.svg','assets/images/fc-26-3.svg']
  },
  {
    id:'gran-turismo-7', title:'Gran Turismo 7', short:'Автоспортивная атмосфера, трассы и коллекция автомобилей.',
    price:5490, platform:'PS4 / PS5', genre:'Racing / Simulator', release:'2022', rating:'3+', page:'gran-turismo-7.html',
    images:['assets/images/gran-turismo-7-1.svg','assets/images/gran-turismo-7-2.svg','assets/images/gran-turismo-7-3.svg']
  }
];
