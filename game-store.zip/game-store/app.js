(() => {
  const products = window.PRODUCTS || [];
  const money = n => new Intl.NumberFormat('ru-RU').format(n) + ' ₽';
  const cartKey = 'bluegame_cart';
  const getCart = () => JSON.parse(localStorage.getItem(cartKey) || '[]');
  const saveCart = cart => { localStorage.setItem(cartKey, JSON.stringify(cart)); updateCart(); };
  const toast = (text) => {
    let el = document.querySelector('.toast');
    if (!el) { el = document.createElement('div'); el.className = 'toast'; document.body.appendChild(el); }
    el.textContent = text; el.classList.add('show'); clearTimeout(window.__toastTimer);
    window.__toastTimer = setTimeout(() => el.classList.remove('show'), 1800);
  };
  const addToCart = id => {
    const cart = getCart(); const found = cart.find(x => x.id === id);
    if (found) found.qty += 1; else cart.push({id, qty:1});
    saveCart(cart); toast('Товар добавлен в корзину');
  };
  const removeFromCart = id => saveCart(getCart().filter(x => x.id !== id));
  const count = cart => cart.reduce((s,x)=>s+x.qty,0);
  const total = cart => cart.reduce((s,x)=>{ const p=products.find(p=>p.id===x.id); return s+(p?p.price*x.qty:0); },0);

  function ensureCartUI(){
    if(document.querySelector('.cart-drawer')) return;
    document.body.insertAdjacentHTML('beforeend', `
      <div class="overlay" data-close-cart></div>
      <aside class="cart-drawer" aria-label="Корзина">
        <div class="cart-head"><div><strong style="font-size:22px">Корзина</strong><div style="color:#7890b2;font-size:13px">Ваши выбранные игры</div></div><button class="icon-btn" data-close-cart>✕</button></div>
        <div class="cart-items"></div>
        <div class="cart-foot"><div class="cart-total"><span>Итого</span><strong data-cart-total>0 ₽</strong></div><button class="primary-btn" style="width:100%" data-checkout>Оформить заказ</button></div>
      </aside>
      <div class="modal" data-modal><div class="modal-card"><div style="font-size:54px">✓</div><h3>Заказ принят</h3><p>Это демонстрационный магазин: оформление работает как интерфейсный сценарий и очищает корзину.</p><button class="primary-btn" data-close-modal>Продолжить</button></div></div>
    `);
    document.querySelectorAll('[data-close-cart]').forEach(el=>el.addEventListener('click',closeCart));
    document.querySelector('[data-checkout]').addEventListener('click', checkout);
    document.querySelector('[data-close-modal]').addEventListener('click',()=>document.querySelector('[data-modal]').classList.remove('show'));
  }
  function openCart(){ ensureCartUI(); updateCart(); document.querySelector('.cart-drawer').classList.add('show'); document.querySelector('.overlay').classList.add('show'); }
  function closeCart(){ document.querySelector('.cart-drawer')?.classList.remove('show'); document.querySelector('.overlay')?.classList.remove('show'); }
  function updateCart(){
    document.querySelectorAll('[data-cart-count]').forEach(el => el.textContent = count(getCart()));
    const itemsEl = document.querySelector('.cart-items'); if(!itemsEl) return;
    const cart = getCart();
    if(!cart.length){ itemsEl.innerHTML='<div class="cart-empty">Корзина пока пуста.<br>Добавьте игру из каталога.</div>'; }
    else itemsEl.innerHTML = cart.map(x=>{ const p=products.find(p=>p.id===x.id); if(!p) return ''; return `<div class="cart-item"><img src="${p.images[0]}" alt="${p.title}"><div><h4>${p.title}</h4><p>${x.qty} × ${money(p.price)}</p></div><button class="cart-remove" data-remove="${p.id}" title="Удалить">×</button></div>`; }).join('');
    document.querySelector('[data-cart-total]').textContent = money(total(cart));
    itemsEl.querySelectorAll('[data-remove]').forEach(btn=>btn.addEventListener('click',()=>removeFromCart(btn.dataset.remove)));
  }
  function checkout(){
    if(!getCart().length){ toast('Корзина пуста'); return; }
    saveCart([]); closeCart(); document.querySelector('[data-modal]').classList.add('show');
  }
  function renderCatalog(filter=''){
    const grid=document.querySelector('[data-catalog]'); if(!grid) return;
    const q=filter.trim().toLowerCase();
    const list=products.filter(p=>`${p.title} ${p.genre} ${p.platform}`.toLowerCase().includes(q));
    const countEl=document.querySelector('[data-result-count]'); if(countEl) countEl.textContent=`Найдено: ${list.length}`;
    grid.innerHTML=list.length?list.map(p=>`
      <article class="product-card">
        <a class="card-image" href="${p.page}"><img src="${p.images[0]}" alt="${p.title}"></a>
        <div class="card-body">
          <div class="card-top"><a class="card-title" href="${p.page}">${p.title}</a><span class="platform">${p.platform.split(' / ')[0]}</span></div>
          <div class="card-desc">${p.short}</div>
          <div class="price-row"><div class="price">${money(p.price)}</div><span style="color:#35d07f;font-size:13px">В наличии</span></div>
          <div class="card-actions"><a class="secondary-btn" href="${p.page}">Подробнее</a><button class="primary-btn" data-add="${p.id}">В корзину</button></div>
        </div>
      </article>`).join(''):'<div class="empty">По вашему запросу ничего не найдено.</div>';
    grid.querySelectorAll('[data-add]').forEach(btn=>btn.addEventListener('click',()=>addToCart(btn.dataset.add)));
  }
  function initProductPage(){
    const root=document.querySelector('[data-product-id]'); if(!root) return;
    const p=products.find(x=>x.id===root.dataset.productId); if(!p) return;
    root.querySelector('[data-main-image]').src=p.images[0];
    root.querySelectorAll('[data-thumb]').forEach((btn,i)=>{btn.querySelector('img').src=p.images[i];btn.addEventListener('click',()=>{root.querySelector('[data-main-image]').src=p.images[i];root.querySelectorAll('[data-thumb]').forEach(x=>x.classList.remove('active'));btn.classList.add('active');});});
    root.querySelectorAll('[data-add-current]').forEach(btn=>btn.addEventListener('click',()=>addToCart(p.id)));
    root.querySelectorAll('[data-buy-current]').forEach(btn=>btn.addEventListener('click',()=>{addToCart(p.id);openCart();}));
  }
  document.addEventListener('DOMContentLoaded',()=>{
    ensureCartUI(); updateCart(); renderCatalog(); initProductPage();
    document.querySelectorAll('[data-open-cart]').forEach(btn=>btn.addEventListener('click',openCart));
    const search=document.querySelector('[data-search]'); if(search) search.addEventListener('input',e=>renderCatalog(e.target.value));
    document.querySelectorAll('[data-scroll-catalog]').forEach(btn=>btn.addEventListener('click',()=>document.querySelector('#catalog')?.scrollIntoView({behavior:'smooth'})));
  });
})();
